class AcaoAposNotaFiscal():
	def executa(self, nota_fiscal):
		pass
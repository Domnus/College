from AcaoAposNotaFiscal import AcaoAposNotaFiscal

class Impressora(AcaoAposNotaFiscal):
	def Executa(self, nota_fiscal):
		print("Imprimindo nota fiscal...")
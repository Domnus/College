class Item():
	def __init__(self, nome, valor):
		self.nome = nome
		self.valor = valor